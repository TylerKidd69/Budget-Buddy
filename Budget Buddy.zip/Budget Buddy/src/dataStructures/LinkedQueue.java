package dataStructures;
import exception.ExceptionCollection;

public class LinkedQueue<T> implements QueueInterface<T>{
	private LinearNode<T> first, last;
	private int size;
	
	//constructors
	public LinkedQueue(T element) {
		first = last = new LinearNode<T>(element);
		size++;
	}
	public LinkedQueue() {
		first = last = null;
	}

	
	//adds an element to the end of the queue in a node
	public void enqueue(T element) {
		LinearNode<T> temp = new LinearNode<T>(element);
		
		//if the queue is empty, assign first to the new node
		if(size == 0)
			first = temp;
		else //if the queue is not empty, set the last node to point to the new node
			last.setNext(temp);
		
		//reassign last to point to the new node
		last = temp;
		size++;
	}
	
	//removes an element from the queue
	public T dequeue() throws ExceptionCollection{
		if(size == 0)
			throw new ExceptionCollection("Queue is empty");
		
		T result = first.getElement();
		first = first.getNext(); //will set first to null if next is null
		size--;
		
		return result;
	}
	
	//returns the element in the front of the queue
	public T first() throws ExceptionCollection{
		if(size == 0)
			throw new ExceptionCollection("Queue is empty");
		
		return first.getElement();
	}
	
	public boolean isEmpty() {
		if(size > 0)
			return false;
		else
			return true;
	}
	
	public int size() { return size; }
	
	public String toString() {
		String result = "";
		LinearNode<T> temp = first;
		
		for(int i = 0; i < size; i++) {
			result += temp;
			temp = temp.getNext();
		}
		return result;
	}
	
}
