package dataStructures;
import exception.ExceptionCollection;

public interface ListInterface<T> {
	/**
	 * Adds an element to the front of the list
	 * @param element element to be added
	 */
	public void addToFront(T element);
	
	/**
	 * Adds an element to the rear of the list
	 * @param element element to be added
	 */
	public void addToRear(T element);
	
	/**
	 * Adds an element after the specified element
	 * @param target position to add the element after
	 * @param element element to be added
	 * @throws ExceptionCollection thrown if there is no target element
	 */
	public void addAfter(T target, T element) throws ExceptionCollection;
	
	/**
	 * Removes the first element in the list
	 * @return returns the element removed
	 * @throws ExceptionCollection thrown if the list is empty
	 */
	public T removeFirst() throws ExceptionCollection;
	
	/**
	 * Removes the last element in the list
	 * @return returns the element removed
	 * @throws ExceptionCollection thrown if the list is empty
	 */
	public T removeLast() throws ExceptionCollection;
	
	/**
	 * Removes a specified element
	 * @param target element to be removed
	 * @return returns the element that was removed
	 * @throws ExceptionCollection thrown if the target element does not exist
	 * or if the list is empty
	 */
	public T remove(T target) throws ExceptionCollection;
	
	/**
	 * Returns the first element in the list
	 * @return Returns the first element in the list
	 * @throws ExceptionCollection thrown if the list is empty
	 */
	public T first() throws ExceptionCollection;
	
	/**
	 * Returns the last element in the list
	 * @return Returns the last element in the list
	 * @throws ExceptionCollection thrown if the list is empty
	 */
	public T last() throws ExceptionCollection;
	
	/**
	 * Checks if there is a specified element in the list
	 * @param element Element to look for in the list
	 * @return Returns true or false based on if the element if found or not
	 */
	public boolean contains(T element);
	
	/**
	 * Checks if there are any elements in the list
	 * @return Returns true or false based on whether there are elements in
	 * the list or not
	 */
	public boolean isEmpty();
	
	/**
	 * Returns the current number of elements in the list
	 * @return an integer value describing the number of elements in the list
	 */
	public int size();
	
	/**
	 * Returns all elements in the list in string form
	 * @return Returns a string describing the elements in the list
	 */
	public String toString();

}
