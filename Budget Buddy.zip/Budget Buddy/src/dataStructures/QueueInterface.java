package dataStructures;
import exception.ExceptionCollection;

public interface QueueInterface<T> {
	public void enqueue(T element);
	public T dequeue() throws ExceptionCollection;
	public T first() throws ExceptionCollection;
	public int size();
	public boolean isEmpty();
	public String toString();
}
