package dataStructures;
import exception.ExceptionCollection;

public interface StackInterface<T>{
	
	/**
	 * adds an object onto the top of the stack
	 * @param element - the object to be added
	 */
	public void push(T element);
	
	/**
	 * removes the object on top of the stack
	 * @return returns the object that is on the top of the stack
	 * @throws ExceptionCollection if the stack is empty
	 */
	public T pop() throws ExceptionCollection;
	
	/**
	 * returns the object on top of the stack without removing it
	 * @return returns the object on top of the stack
	 * @throws ExceptionCollection if the stack is empty
	 */
	public T peek() throws ExceptionCollection;
	
	/**
	 * will return the size of the stack
	 * @return returns the size of the stack as an int
	 */
	public int size();
	
	/**
	 * lets you know if the stack is currently empty or not
	 * @return true or false
	 */
	public boolean isEmpty();
	
	/**
	 * displays all information in the stack as a string
	 * @return string
	 */
	public String toString();
}
