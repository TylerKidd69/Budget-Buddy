package dataStructures;
import java.io.Serializable;

public class LinearNode<T> implements Serializable{
	private LinearNode<T> next, previous; //previous and next implementation
	private int index;
	private T element;
	
	//constructors
	public LinearNode(T element, int index) {
		this.element = element;
		next = previous = null;
		this.index = index;
	}
	public LinearNode(T element) {
		this.element = element;
		next = previous = null;
		index = -1;
	}
	public LinearNode() {
		element = null;
		next = previous = null;
		index = -1;
	}
	
	//getters, setter, toString
	public void setElement(T element) { this.element = element; }
	public void setNext(LinearNode<T> next) { this.next = next; }
	public void setPrevious(LinearNode<T> previous) { this.previous = previous; }
	public void setIndex(int index) { this.index = index; }
	
	public T getElement() { return element; }
	public LinearNode<T> getNext() { return next; }
	public LinearNode<T> getPrevious() { return previous; }
	public int getIndex() { return index; }
	
	public String toString() {
		return element + "\nNext:\n" + next + "\nPrevious:\n" + previous;
	}
}