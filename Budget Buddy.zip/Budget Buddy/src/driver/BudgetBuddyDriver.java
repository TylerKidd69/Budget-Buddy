package driver;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import financialPlanner.Planner;
import dataStructures.IndexedList;
import accounts.*;
import utility.*;

public class BudgetBuddyDriver {
	public static Scanner scan = new Scanner(System.in);
	//number of options in the various menus
	public static final int MENU_OPTIONS = 7, PLANNER_OPTIONS = 10, SAVINGS_OPTIONS = 2;
	public static final String FILE_NAME = "planners.ser";
	public static IndexedList<Planner> planners = new IndexedList<Planner>();


	public static void main(String[] args) throws IOException {
		int choice; //used for menus
		Planner currentPlanner = null; //the current "loaded" planner



		try {
			FileInputStream fileIn = new FileInputStream(FILE_NAME);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			planners = (IndexedList<Planner>)in.readObject();
			in.close();
			fileIn.close();
		} catch(IOException x) {
			//x.printStackTrace();
		} catch(ClassNotFoundException y) {
			//y.printStackTrace();
		}		



		System.out.println("*******Welcome to Budget Buddy 0.1*******");
		Utility.screenbreak();
		do {
			System.out.println("Please select an option:");
			choice = mainMenu();

			switch(choice) {
			case 1:
				//planner creation auto adds the new planner as the "loaded" planner
				currentPlanner = createPlanner();
				break;
			case 2:
				if(planners.size() > 0) {
					currentPlanner = loadPlanner();
					//Planner.startScanner();
				}
				else
					System.out.println("There are no planners. Create a planner.");
				Utility.screenbreak();
				break;
			case 3:
				savePlanners(FILE_NAME, planners);
				break;
			case 4: 
				if(currentPlanner == null) {
					System.out.println("Please load a planner first");
					break;
				}
				editPlanner(currentPlanner);
				break;
			case 5:
				if(currentPlanner == null) {
					System.out.println("Please load a planner first");
					break;
				}
				viewPlanner(currentPlanner);
				break;
			case 6:
				deletePlanner(loadPlanner());
			}


		}while(choice != MENU_OPTIONS);


		//would like to implement a random money management quote here thats different every time
	}




	private static Planner createPlanner() {
		String name;
		Planner newPlanner;
		scan.nextLine(); //clearing input stream

		System.out.print("Please enter in your name: ");
		name = scan.nextLine();
		if(name.length()>15)
			name = name.substring(0, 16); //name has max of 12 characters
		Utility.screenbreak();

		newPlanner = new Planner(name);
		planners.addToRear(newPlanner);
		System.out.println("Planner created*");
		Utility.screenbreak();

		return newPlanner;
	}


	private static void editPlanner(Planner planner) {
		int choice; //used for the edit menu
		boolean doubleCheck;

		System.out.println("Current Planner:\n" + planner);
		Utility.screenbreak();

		do {
			System.out.println("Please select an option:");
			choice = editMenu();

			switch(choice) {
			case 1:
				System.out.print("Enter Income: ");
				planner.setPay(scan.nextDouble());
				break;
			case 2:
				//process income
				System.out.println("Coming soon!");
				break;
			case 3:
				planner.addBill(createBill());
				break;
			case 4:
				choice = savingsMenu();
				if(choice == 1)
					planner.addSaving(createSavings());
				else if(choice == 2)
					planner.addPercent(createPercent(planner.getRemainingPercent()));
				break;
			case 5:
				planner.editAccounts("edit");
				break;
			case 6:
				planner.editAccounts("delete");
				break;
			case 7:
				planner.sortAccounts();
				break;
			case 8:
				viewPlanner(planner);
				break;
			case 9:
				doubleCheck = Utility.yesOrNo("Are you sure you want to delete the planner " + planner.getName() + "?");
				if(doubleCheck)
					planners.remove(planner);
			}
		} while(choice != PLANNER_OPTIONS);


	}


	private static Planner loadPlanner(){
		int choice;

		System.out.println("Please select a planner:");
		choice = plannerMenu();

		return planners.getElement(choice-1);
	}


	private static void viewPlanner(Planner planner) {
		System.out.println(planner);
		Utility.screenbreak();
	}


	private static void deletePlanner(Planner planner) {
		boolean result;
		result = Utility.yesOrNo("Are you sure you want to delete the planner " + planner.getName() + "?");
		if(result)
			planners.remove(planner);
		
		Utility.screenbreak();
	}


	private static void savePlanners(String fileName, IndexedList<Planner> planners) throws IOException {
		try {
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(planners);
			oos.flush();
			oos.close();
			fos.close();
		} catch(IOException x) {
			x.printStackTrace();
		}
	}


	private static int mainMenu() {
		int choice;

		do {
			System.out.println("1. Create new financial planner\n"
					+ "2. Load existing financial planner\n"
					+ "3. Save current financial planner\n"
					+ "4. Edit financial planner\n"
					+ "5. View financial planner\n"
					+ "6. Delete financial planner\n"
					+ "7. Exit Budget Buddy\n");


			choice = scan.nextInt();

			if(choice < 1 || choice > MENU_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > MENU_OPTIONS);

		return choice;
	}


	private static int plannerMenu() {
		int choice;

		do {
			for(int count = 0; count < planners.size(); count++)
				System.out.println((count+1) + ". " + planners.getElement(count).getName());

			choice = scan.nextInt();

			if(choice < 1 || choice > planners.size())
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > planners.size());

		return choice;
	}


	private static int editMenu() {
		int choice;

		do {
			System.out.println("1. Enter income\n"
					+ "2. Process Income\n"
					+ "3. Add Bill\n"
					+ "4. Add Savings Account\n"
					+ "5. Edit an Account\n"
					+ "6. Delete an Account\n"
					+ "7. Sort Accounts\n"
					+ "8. View Planner\n"
					+ "9. Delete Planner\n"
					+ "10. Main Menu\n");

			choice = scan.nextInt();

			if(choice < 1 || choice > PLANNER_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > PLANNER_OPTIONS);

		return choice;
	}


	private static int savingsMenu() {
		int choice;

		do {
			System.out.println("1. Manual Savings Account\n"
					+ "2. Percent Savings Account\n");

			choice = scan.nextInt();

			if(choice < 1 || choice > SAVINGS_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > SAVINGS_OPTIONS);

		return choice;
	}


	private static Bill createBill() {
		String name;
		Double limit;
		scan.nextLine();//clearing input stream

		System.out.print("Name of Bill: ");
		name = scan.nextLine();

		if(name.length()>15) //account names have a max of 15 characters
			name = name.substring(0, 16);


		System.out.print("Bill amount: ");
		limit = scan.nextDouble();
		Utility.screenbreak();

		return new Bill(name, limit);
	}

	private static Saving createSavings() {
		String name;
		double limit;
		boolean hasLimit;
		scan.nextLine(); //clearing input stream

		System.out.print("Name of Savings Account: ");
		name = scan.nextLine();

		if(name.length()>15)
			name = name.substring(0, 16);

		hasLimit = Utility.yesOrNo("Do you want a max limit on the account?");
		Utility.screenbreak();
		if(hasLimit) {
			System.out.print("Max Limit: ");
			limit = scan.nextDouble();
			return new Saving(name, limit);
		}
		else
			return new Saving(name);

	}

	private static Percent createPercent(int remainingPercent) {
		String name;
		int percent;
		double limit;
		boolean hasLimit;
		Percent newPercent;
		scan.nextLine();

		System.out.print("Name of Savings Account: ");
		name = scan.nextLine();

		if(name.length()>15) //account names have a max of 12 characters
			name = name.substring(0, 16); 


		System.out.print("Account Percentage: ");
		percent = scan.nextInt();

		hasLimit = Utility.yesOrNo("Do you want a max limit on the account?");
		if(hasLimit) {
			System.out.print("Max Limit: ");
			limit = scan.nextDouble();
			newPercent = new Percent(name, limit, percent);
		}
		else
			newPercent = new Percent(name, percent);

		return newPercent;
	}

}
