package driver;
import java.util.Scanner;
import financialPlanner.Planner;
import dataStructures.IndexedList;
import accounts.*;

public class BudgetBuddyDriver {
	public static Scanner scan = new Scanner(System.in);
	//number of options in the various menus
	public static final int MENU_OPTIONS = 7, EDIT_OPTIONS = 8;
	public static IndexedList<Planner> planners;

	
	public static void main(String[] args) {
		boolean restart;
		int choice; //used for menus
		Planner currentPlanner = null; //the current "loaded" planner

		System.out.println("*******Welcome to Budget Buddy 0.1*******");
		screenbreak();
		do {
			System.out.println("Please select an option:");
			choice = mainMenu();

			switch(choice) {
			case 1:
				//planner creation auto adds the new planner as the "loaded" planner
				currentPlanner = createPlanner();
				break;
			case 2:
				currentPlanner = loadPlanner();
				break;
			case 3: 
				if(currentPlanner == null) {
					System.out.println("Please load a planner first");
					break;
				}
				editPlanner(currentPlanner);
				break;
			case 4:
				if(currentPlanner == null) {
					System.out.println("Please load a planner first");
					break;
				}
				viewPlanner(currentPlanner);
				break;
			case 5:
				if(currentPlanner == null) {
					System.out.println("Please load a planner first");
					break;
				}
				deletePlanner(loadPlanner());
				break;
			case 6:
				savePlanners(); //need to implement
			}
			if(choice == MENU_OPTIONS)
				break;


			restart = yesOrNo("Main Menu?");		
		}while(restart);

	}


	
	
	private static Planner createPlanner() {
		String name;
		Planner newPlanner;
		
		System.out.print("Please enter in your name: ");
		name = scan.nextLine().substring(0, 13); //name has max of 12 characters
		screenbreak();

		scan.nextLine();//clearing the input stream
		
		newPlanner = new Planner(name);
		planners.addToRear(newPlanner);
		System.out.println("Planner created*");

		return newPlanner;
	}

	
	private static Planner editPlanner(Planner planner) {
		int choice; //used for the edit menu
		
		System.out.println("Current Planner:\n" + planner);
		screenbreak();
		
		do {
			System.out.println("Please select an option:");
			choice = editMenu();

			switch(choice) {
			case 1:
				System.out.print("Enter Income: ");
				planner.setPay(scan.nextDouble());
				break;
			case 2:
				planner.addBill(createBill());
				break;
			case 3:
				
			}
		} while()
		
		
	}
	
	
	private static Planner loadPlanner() {

	}

	
	private static void viewPlanner(Planner planner) {
		System.out.println(planner);
	}
	
	
	private static void deletePlanner(Planner planner) {
		planners.remove(planner);
	}
	
	
	private static void savePlanners() {
		aewf
	}

	
	private static int mainMenu() {
		int choice;

		do {
			System.out.println("1. Create new financial planner\n"
					+ "2. Load existing financial planner"
					+ "3. Save current financial planner"
					+ "4. Edit financial planner"
					+ "5. View financial planner"
					+ "6. Delete financial planner"
					+ "7. Exit Budget Buddy");

			choice = scan.nextInt();

			if(choice < 1 || choice > MENU_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > MENU_OPTIONS);

		return choice;
	}
	
	
	private static int editMenu() {
		int choice;

		do {
			System.out.println("1. Enter income\n"
					+ "2. Add Bill"
					+ "3. Add Savings Account"
					+ "4. Edit Account"
					+ "5. Delete Account"
					+ "6. View Planner"
					+ "7. Delete Planner"
					+ "8. Main Menu");

			choice = scan.nextInt();

			if(choice < 1 || choice > EDIT_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > EDIT_OPTIONS);

		return choice;
	}
	
	
	private static Bill createBill() {
		String name;
		Double limit;
		System.out.print("Name of Bill: ");
		name = scan.nextLine();
		scan.nextLine(); //clearing input stream
		
		System.out.print("Bill amount: ");
		limit = scan.nextDouble();
		
		return new Bill(name, limit);
	}


	private static boolean yesOrNo(String title) {
		char restart;
		System.out.print(title + " (Y/N)");
		restart = scan.next().charAt(0);

		if(restart == 'y' || restart == 'Y')
			return true;
		else
			return false;
	}

	private static void screenbreak() {
		System.out.println();
		System.out.println();
	}
}
