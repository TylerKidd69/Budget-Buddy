package financialPlanner;
import dataStructures.IndexedList;
import accounts.*;
import java.io.Serializable;

public class Planner implements Serializable{

	String name;
	double pay;
	IndexedList<Bill> bills;
	IndexedList<Percent> percents;
	IndexedList<Saving> savings;
	
	public Planner(String name) {
		this.name = name;
		pay = 0;
	}
	
	public void setPay(double pay) { this.pay = pay; }
	public double getPay() { return pay; }
	
	
	public void addBill(String name, double limit) {
		bills.addToRear(new Bill(name, limit));
	}
	public void addBill(Bill bill) {
		bills.addToRear(bill);
	}
	
	public void removeBill(Bill bill) {
		bills.remove(bill);
	}
	
	
	public void addPercent(String name, int percent) {
		percents.addToRear(new Percent(name, percent));
	}
	public void addPercent(String name, double limit, int percent) {
		percents.addToRear(new Percent(name, limit, percent));
	}
	public void addPercent(Percent percent) {
		percents.addToRear(percent);
	}
	
	public void removePercent(Percent percent) {
		percents.remove(percent);
	}
	
	public void addSaving(String name, double limit) {
		savings.addToRear(new Saving(name, limit));
	}
	public void addSaving(String name) {
		savings.addToRear(new Saving(name));
	}
	//Need to implement: public void addSaving(String name, double limit, ***due date***)
	public void addSaving(Saving saving) {
		savings.addToRear(saving);
	}
	
	public void removeSavings(Saving saving) {
		savings.remove(saving);
	}
	
	
	public String toString() {
		String result = "";
		
		result += name + "\nAccount Type\tAccount Name\tBalance\tLimit"
				+ "\nBills:\n" + bills
				+ "\nSavings Accounts:\n" + savings
				+ "\nPercent Accounts:\n" + percents;
		
		return result;
	}
}
