package financialPlanner;
import dataStructures.IndexedList;
import accounts.*;
import java.io.Serializable;
import java.util.Scanner;
import utility.*;

public class Planner implements Serializable{

	static Scanner scan = new Scanner(System.in);
	String name;
	double pay;
	IndexedList<Bill> bills = new IndexedList<Bill>();
	IndexedList<Percent> percents = new IndexedList<Percent>();
	IndexedList<Saving> savings = new IndexedList<Saving>();
	public Percent fillAccount = null; //account to fill totalPercent to 100
	public int totalPercent = 0; //current percentages added up from all percent accounts
	//used for the menus
	private static final int TYPE_OPTIONS = 3;

	public Planner(String name) {
		this.name = name;
		pay = 0;
		totalPercent = 0;
		fillAccount = null;
	}

	public void setPay(double pay) { this.pay = pay; }
	public double getPay() { return pay; }


	public void addBill(String name, double limit) {
		bills.addToRear(new Bill(name, limit));
	}
	public void addBill(Bill bill) {
		bills.addToRear(bill);
	}

	public void removeBill(Bill bill) {
		bills.remove(bill);
	}


	public void addPercent(String name, int percent) {
		percents.addToRear(new Percent(name, percent));
		totalPercent += percent;
	}
	public void addPercent(String name, double limit, int percent) {
		percents.addToRear(new Percent(name, limit, percent));
		totalPercent += percent;
	}
	public void addPercent(Percent percent) {
		percents.addToRear(percent);
		totalPercent += percent.getPercent();
	}

	public void removePercent(Percent percent) {
		percents.remove(percent);
	}

	public void addSaving(String name, double limit) {
		savings.addToRear(new Saving(name, limit));
	}
	public void addSaving(String name) {
		savings.addToRear(new Saving(name));
	}
	//Need to implement: public void addSaving(String name, double limit, ***due date***)
	public void addSaving(Saving saving) {
		savings.addToRear(saving);
	}

	public void removeSavings(Saving saving) {
		savings.remove(saving);
	}

	public void setFillAccount(Percent fillPercent) {
		fillAccount = fillPercent;
	}
	public Percent getFillAccount() {
		return fillAccount;
	}

	public int getRemainingPercent() {
		return 100-totalPercent;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public void sortAccounts() {
		Bill[] bArray = new Bill[bills.size()];
		Saving[] sArray = new Saving[savings.size()];
		Percent[] pArray = new Percent[percents.size()];
		
		bills.toArray(bArray);
		savings.toArray(sArray);
		percents.toArray(pArray);
		
		
		Sorting.bubbleSort(bArray);
		Sorting.bubbleSort(sArray);
		Sorting.bubbleSort(pArray);
		
	}


	public void editAccounts(String editType) {
		int choice;


		System.out.println("Please select an account type to " + editType + ":\n");
		choice = typeMenu();

		switch(choice) {
		case 1:
			editAccountType(bills, "bill", editType);
			break;
		case 2:
			editAccountType(savings, "savings account", editType);
			break;
		case 3:
			editAccountType(percents, "percent account", editType);
		}

	}

	private <T> void editAccountType(IndexedList<T> accounts, String type, String editType) {
		int choice;
		boolean restart;
		Account temp;

		do {
			System.out.println("Please select a " + type + " to " + editType + ":\n");
			choice = accountMenu(accounts, type);
			if(choice == 0)
				break;

			temp = (Account)accounts.getElement(choice-1);
			if(editType.equals("edit"))
				temp.edit();
			else if(editType.equals("delete"))
				accounts.remove((T)temp);

			restart = Utility.yesOrNo("Would you like to " + editType + " another " + type + "?");
		}while(restart);
		
		Utility.screenbreak();
	}


	private <T> int accountMenu(IndexedList<T> accounts, String type) {
		int choice;

		do {
			if(accounts.isEmpty()) {
				System.out.println("There are no " + type + "s");
				return 0;
			}
			else
				for(int count = 0; count < accounts.size(); count++) {
					System.out.println((count+1) + ". " + ((Account)accounts.getElement(count)).getName() + "\n");
				}

			System.out.print("Select an account: ");
			choice = scan.nextInt();

			if(choice < 1 || choice > accounts.size())
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > accounts.size());

		return choice;
	}

	private int typeMenu() {
		int choice;

		do {
			System.out.println("1. Bill\n"
					+ "2. Manual Savings Account\n"
					+ "3. Percent Savings Account\n");

			choice = scan.nextInt();

			if(choice < 1 || choice > TYPE_OPTIONS)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > TYPE_OPTIONS);

		return choice;
	}


	public String toString() {
		String result = "";

		result += name + ": $" + pay + "\nAccount Name\t\tAccount Type\tBalance\t\tLimit\n"
				+ bills
				+ savings
				+ percents;

		return result;
	}
}
