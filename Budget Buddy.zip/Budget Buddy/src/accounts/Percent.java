package accounts;
import java.io.Serializable;

import utility.Utility;

public class Percent extends Account implements Comparable<Percent>, Serializable{
	public static int remainingPercent = 100;
	public static int count;
	private int percent;
	private static String type = "Percent";
	
	public Percent(String name, double limit, int percent) {
		super(name, limit, type + " (%" + percent + ")");
		this.percent = percent;
		remainingPercent -= percent;
	}
	public Percent(String name, int percent) {
		super(name, type + "(%" + percent + ")");
		this.percent = percent;
		remainingPercent -= percent;
	}
	
	public void pay(double income) {
		balance += (percent/100)*income; //converts the int percent into a decimal number
	}
	
	public void edit() {
		int choice;
		boolean restart;
		
		do {
			choice = editMenu();

			switch(choice) {
			case 1:
				System.out.print("Enter in new name: ");
				scan.nextLine();
				this.setName(scan.nextLine());
				break;
			case 2:
				System.out.print("Enter in a limit (0 = no limit): ");
				this.setLimit(scan.nextDouble());
				if(limit == 0)
					hasLimit = false;
				break;
			case 3:
				System.out.println("Enter in a new percent not to exceed " + remainingPercent + "%: ");
			}
		
		restart = Utility.yesOrNo("Continue editing?");
		}while(restart);
		
	}
	
	public int editMenu() {
		int choice;
		
		do {
			System.out.println("What would you like to edit?\n"
					+ "1. Name\n"
					+ "2. Limit\n"
					+ "3. Percent\n");
			
			choice = scan.nextInt();
			
			if(choice < 1 || choice > 3)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > 3);
		
		return choice;
	}
	
	public void recoverPercent() { remainingPercent += percent; }
	
	public void setPercent(int percent) { this.percent = percent; }
	public int getPercent() { return percent; }
	
	public int compareTo(Percent other) {
		//comparing percents then name if needed
		if(percent > ((Percent) other).getPercent())
			return 1;
		else if(percent < ((Percent) other).getPercent())
			return -1;
		else if(percent == ((Percent) other).getPercent())
			return name.compareTo(((Percent) other).getName());
		else
			return 0;
	}
}
