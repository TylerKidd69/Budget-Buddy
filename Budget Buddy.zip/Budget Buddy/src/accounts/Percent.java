package accounts;
import java.io.Serializable;

public class Percent extends Account implements Comparable, Serializable{

	public static int totalPercent = 0, count;
	public static Percent fillAccount;
	private int percent;
	
	public Percent(String name, double limit, int percent) {
		super(name, limit);
		this.percent = percent;
	}
	public Percent(String name, int percent) {
		super(name);
		this.percent = percent;
	}
	
	public static int getRemainingPercent() { return 100-totalPercent; }
	
	public void pay(double income) {
		balance += (percent/100)*income; //converts the int percent into a decimal number
	}
	
	public void setPercent(int percent) { this.percent = percent; }
	public int getPercent() { return percent; }
	
	public int compareTo(Object other) {
		if(percent > ((Percent) other).getPercent())
			return 1;
		else if(percent < ((Percent) other).getPercent())
			return -1;
		else
			return super.compareTo(other);
	}
}
