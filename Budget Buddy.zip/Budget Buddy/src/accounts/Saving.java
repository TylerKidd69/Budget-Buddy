package accounts;
import java.io.Serializable;

import utility.Utility;

public class Saving extends Account implements Comparable<Saving>, Serializable{
	private static String type = "Manual";
	
	public Saving(String name, double limit) {
		super(name, limit, type);
	}
	
	public Saving(String name) {
		super(name, type);
	}
	
	public void deductWhole() {
		balance = 0;
	}
	
	public void edit() {
		int choice = 0;
		boolean restart;
		
		do {
			choice = editMenu();

			switch(choice) {
			case 1:
				System.out.print("Enter in new name: ");
				scan.nextLine(); //clearing input stream
				this.setName(scan.nextLine());
				break;
			case 2:
				System.out.print("Enter in a limit (0 = no limit): ");
				this.setLimit(scan.nextDouble());
				if(limit == 0)
					hasLimit = false;
				break;
			}
			
		restart = Utility.yesOrNo("Continue editing?");
		}while(restart);
		
	}
	
	public int editMenu() {
		int choice;
		
		do {
			System.out.println("What would you like to edit?\n"
					+ "1. Name\n"
					+ "2. Limit\n");
			
			choice = scan.nextInt();
			
			if(choice < 1 || choice > 2)
				System.out.println("Invalid option.\n");

		}while(choice < 1 || choice > 2);
		
		return choice;
	}
	
	
	public int compareTo(Saving other) {		
		//comparing balance then name if needed
		if(balance > ((Account) other).getBalance())
			return 1;
		else if(balance < ((Account) other).getBalance())
			return -1;
		else if(balance == ((Account) other).getBalance())
			return name.compareTo(((Account) other).getName());
		else
			return 0;
	}
	
	
	public String toString() {
		return super.toString();
	}
}
