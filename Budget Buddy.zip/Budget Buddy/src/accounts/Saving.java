package accounts;
import java.io.Serializable;

public class Saving extends Account implements Serializable{
	//need to implement calendar for Savings accounts that have a "due date"
	//public Savings(String name, double limit, ***due date***){};
	
	public Saving(String name, double limit) {
		super(name, limit);
	}
	
	public Saving(String name) {
		super(name);
	}
	
	public void deductWhole() {
		balance = 0;
	}
	
	public String toString() {
		return super.toString();
	}
}
