package accounts;
import java.io.Serializable;

public class Bill extends Account implements Serializable{
	
	//constructor needs to implement calendar stuff for the due date
	public Bill(String name, double limit) {
		super(name, limit);
	}
	
	public void payWhole() { balance = 0; }
	public void payAmount(double amount) { deductAmount(amount); }
	
	public String getName() { return this.getName(); }
	
	public String toString() {
		return super.toString();
	}
}
