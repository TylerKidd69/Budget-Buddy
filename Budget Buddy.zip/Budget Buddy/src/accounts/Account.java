package accounts;
import exception.ExceptionCollection;
import java.io.Serializable;

public class Account implements Comparable, Serializable{

	protected double balance;
	protected double limit;
	protected boolean hasLimit;
	private String name;
	
	public Account(String name, double limit) {
		this.name = name;
		this.limit = limit;
		hasLimit = true;
		balance = 0;
	}
	public Account(String name) {
		this.name = name;
		limit = -1;
		hasLimit = false;
		balance = 0;
	}
	
	public void setName(String name) { this.name = name.substring(0, 13); }
	public String getName() { return name; }
	
	public void addAmount(double amount) {
		balance += amount;
	}
	
	public void deductAmount(double amount) throws ExceptionCollection{
		balance -= amount;
		if(balance < 0) //Cannot deduct the balance to be lower than 0
			throw new ExceptionCollection("Inadequate Funds");
		//may need to reinstantiate balance to is previous amount
		//balance += amount;
	}
	
	public double getBalance() { return balance; }
	
	public void setLimit(double limit) { this.limit = limit; }
	public double getLimit() { return limit; }

	public void setHasLimit(boolean hasLimit) { this.hasLimit = hasLimit; }
	public boolean getHasLimit() { return hasLimit; }
	
	public int compareTo(Object other) {
		//an account with a limit is greater than an account without a limit
		if(hasLimit && !((Account) other).getHasLimit())
			return 1;
		else if(!hasLimit && ((Account) other).getHasLimit())
			return -1;
		
		//account with the greatest limit is greater
		else if(hasLimit && ((Account) other).getHasLimit()) {
			if(limit > ((Account) other).getLimit())
				return 1;
			else if(limit < ((Account) other).getLimit())
				return -1;
			else
				return 0;
		}
		
		//account with the greatest balance is greater
		else {
			if(balance > ((Account) other).getBalance())
				return 1;
			else if(balance < ((Account) other).getBalance())
				return -1;
			else
				return 0;
		}
	}
	
	
	public String toString() {
		String result = name;
		
		if(name.length() < 5)
			result += "\t\t";
		else if(name.length() < 9)
			result += "\t";
		
		result += "\t" + balance;
		
		if(hasLimit)
			result += "\t" + limit;
		else
			result += "\tNo Limit";
		
		return result;
	}
	
}
