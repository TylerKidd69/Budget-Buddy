package accounts;
import exception.ExceptionCollection;
import java.io.Serializable;
import java.util.Scanner;

public abstract class Account implements Serializable{
	protected static Scanner scan = new Scanner(System.in);
	protected double balance;
	protected double limit;
	protected boolean hasLimit;
	protected String name, type;

	public Account(String name, double limit, String type) {
		this.name = name;
		this.limit = limit;
		hasLimit = true;
		balance = 0;
		this.type = type;
	}
	public Account(String name, String type) {
		this.name = name;
		limit = -1;
		hasLimit = false;
		balance = 0;
		this.type = type;
	}

	public abstract void edit();

	public void setName(String name) { 
		if(name.length() > 15)
			this.name = name.substring(0, 16);
		else
			this.name = name;

	}

	public String getName() { return name; }

	public void addAmount(double amount) {
		balance += amount;
	}

	public void deductAmount(double amount) throws ExceptionCollection{
		balance -= amount;
		if(balance < 0) //Cannot deduct the balance to be lower than 0
			throw new ExceptionCollection("Inadequate Funds");
		//may need to reinstantiate balance to is previous amount
		//balance += amount;
	}

	public double getBalance() { return balance; }

	public void setLimit(double limit) { this.limit = limit; }
	public double getLimit() { return limit; }

	public void setHasLimit(boolean hasLimit) { this.hasLimit = hasLimit; }
	public boolean getHasLimit() { return hasLimit; }


	public String toString() {
		String result = name;

		if(name.length() < 8)
			result += "\t\t";
		else
			result += "\t";

		result += "\t" + type;

		if(type.length() < 9)
			result += "\t\t" + balance;
		else
			result += "\t" + balance;

		if(hasLimit)
			result += "\t\t" + limit;
		else
			result += "\t\tNo Limit";

		return result;
	}

}
