package utility;

import java.util.Scanner;

public final class Utility {
	private static Scanner scan = new Scanner(System.in);

	public static void screenbreak() {
		System.out.println();
		System.out.println();
	}
	
	public static boolean yesOrNo(String title) {
		char restart;
		System.out.print(title + " (Y/N)");
		restart = scan.next().charAt(0);

		if(restart == 'y' || restart == 'Y')
			return true;
		else
			return false;
	}
}
